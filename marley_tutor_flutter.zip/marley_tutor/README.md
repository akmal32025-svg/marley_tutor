# Marley — معلمك الذكي 🎓

تطبيق Flutter تعليمي ذكي مدعوم بـ Claude AI

## المميزات
- 6 مواد دراسية: رياضيات، علوم، تاريخ، لغة عربية، جغرافيا، عام
- وضع الشرح: محادثة مباشرة مع معلم ذكي
- وضع الاختبار: أسئلة MCQ مع شرح الإجابات
- تصميم عربي أنيق بالكامل

## متطلبات التشغيل
- Flutter SDK >= 3.0.0
- Dart SDK >= 3.0.0
- مفتاح Anthropic API

## خطوات الإعداد

### 1. تثبيت المتطلبات
```bash
flutter pub get
```

### 2. إضافة مفتاح API
افتح الملف: `lib/services/claude_service.dart`
وغيّر السطر:
```dart
static const String _apiKey = 'YOUR_ANTHROPIC_API_KEY';
```
إلى مفتاحك الحقيقي من: https://console.anthropic.com

### 3. تشغيل التطبيق
```bash
# للمحاكي أو الجهاز
flutter run

# بناء APK للأندرويد
flutter build apk --release

# بناء IPA للـ iOS
flutter build ipa
```

## هيكل المشروع
```
lib/
├── main.dart                  # نقطة البداية
├── models.dart                # النماذج والثوابت
├── services/
│   └── claude_service.dart    # التواصل مع Claude API
└── screens/
    ├── home_screen.dart       # الشاشة الرئيسية
    ├── chat_screen.dart       # شاشة الشرح
    └── quiz_screen.dart       # شاشة الاختبار
```
