import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models.dart';

class ClaudeService {
  static const String _apiUrl = 'https://api.anthropic.com/v1/messages';
  // ⚠️ ضع مفتاح API الخاص بك هنا
  static const String _apiKey = 'YOUR_ANTHROPIC_API_KEY';
  static const String _model = 'claude-sonnet-4-20250514';

  /// إرسال رسالة في وضع الشرح
  static Future<String> sendChat({
    required List<ChatMessage> messages,
    required String systemPrompt,
  }) async {
    final body = jsonEncode({
      'model': _model,
      'max_tokens': 1024,
      'system': systemPrompt,
      'messages': messages
          .map((m) => {'role': m.role, 'content': m.content})
          .toList(),
    });

    final response = await http.post(
      Uri.parse(_apiUrl),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': _apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: body,
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      final content = data['content'] as List;
      return content
          .where((b) => b['type'] == 'text')
          .map((b) => b['text'] as String)
          .join('');
    } else {
      throw Exception('خطأ في API: ${response.statusCode}');
    }
  }

  /// توليد سؤال اختيار متعدد
  static Future<QuizQuestion> generateQuiz(Subject subject) async {
    const prompt = '''
أنشئ سؤال اختيار من متعدد بالعربية.
أجب فقط بـ JSON بهذا الشكل بدون أي نص آخر أو ```json:
{
  "question": "...",
  "options": ["أ) ...", "ب) ...", "ج) ...", "د) ..."],
  "correct": 0,
  "explanation": "..."
}
''';

    final body = jsonEncode({
      'model': _model,
      'max_tokens': 800,
      'system': subject.systemPrompt,
      'messages': [
        {'role': 'user', 'content': 'اطرح عليّ سؤال اختيار متعدد في ${subject.label}. $prompt'}
      ],
    });

    final response = await http.post(
      Uri.parse(_apiUrl),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': _apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: body,
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      final content = data['content'] as List;
      final text = content
          .where((b) => b['type'] == 'text')
          .map((b) => b['text'] as String)
          .join('');
      final clean = text.replaceAll(RegExp(r'```json|```'), '').trim();
      final json = jsonDecode(clean) as Map<String, dynamic>;
      return QuizQuestion.fromJson(json);
    } else {
      throw Exception('خطأ في توليد السؤال: ${response.statusCode}');
    }
  }
}
