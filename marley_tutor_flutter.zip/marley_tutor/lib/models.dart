import 'package:flutter/material.dart';

class Subject {
  final String id;
  final String label;
  final String icon;
  final Color color;
  final String desc;
  final String systemPrompt;

  const Subject({
    required this.id,
    required this.label,
    required this.icon,
    required this.color,
    required this.desc,
    required this.systemPrompt,
  });
}

const List<Subject> kSubjects = [
  Subject(
    id: 'math',
    label: 'الرياضيات',
    icon: '∑',
    color: Color(0xFFE8643A),
    desc: 'جبر، هندسة، حساب',
    systemPrompt:
        'أنت أستاذ رياضيات بارع. اشرح بخطوات واضحة مع أمثلة. استخدم اللغة العربية دائماً.',
  ),
  Subject(
    id: 'science',
    label: 'العلوم',
    icon: '⚗',
    color: Color(0xFF3A9E8F),
    desc: 'فيزياء، كيمياء، أحياء',
    systemPrompt:
        'أنت معلم علوم متحمس. اشرح المفاهيم ببساطة مع أمثلة من الحياة. استخدم اللغة العربية دائماً.',
  ),
  Subject(
    id: 'history',
    label: 'التاريخ',
    icon: '🏛',
    color: Color(0xFF8F6A3A),
    desc: 'تواريخ، حضارات، أحداث',
    systemPrompt:
        'أنت مؤرخ موهوب. اروِ الأحداث بأسلوب شيّق وممتع. استخدم اللغة العربية دائماً.',
  ),
  Subject(
    id: 'language',
    label: 'اللغة العربية',
    icon: 'ق',
    color: Color(0xFF6A3A9E),
    desc: 'قواعد، أدب، إملاء',
    systemPrompt:
        'أنت أستاذ لغة عربية متمكن. صحّح وعلّم بأسلوب راقٍ. استخدم اللغة العربية دائماً.',
  ),
  Subject(
    id: 'geography',
    label: 'الجغرافيا',
    icon: '🌍',
    color: Color(0xFF3A6A9E),
    desc: 'دول، خرائط، طبيعة',
    systemPrompt:
        'أنت خبير جغرافيا. اشرح بوصف دقيق وحيوي. استخدم اللغة العربية دائماً.',
  ),
  Subject(
    id: 'general',
    label: 'عام',
    icon: '💡',
    color: Color(0xFF9E3A6A),
    desc: 'أي سؤال يخطر ببالك',
    systemPrompt:
        'أنت معلم ذكي ومتحمس لكل المواضيع. أجب بدقة وبساطة. استخدم اللغة العربية دائماً.',
  ),
];

class ChatMessage {
  final String role; // 'user' or 'assistant'
  final String content;
  final DateTime timestamp;

  ChatMessage({
    required this.role,
    required this.content,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();
}

class QuizQuestion {
  final String question;
  final List<String> options;
  final int correct;
  final String explanation;

  const QuizQuestion({
    required this.question,
    required this.options,
    required this.correct,
    required this.explanation,
  });

  factory QuizQuestion.fromJson(Map<String, dynamic> json) {
    return QuizQuestion(
      question: json['question'] as String,
      options: List<String>.from(json['options'] as List),
      correct: json['correct'] as int,
      explanation: json['explanation'] as String,
    );
  }
}
