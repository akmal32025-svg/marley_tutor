import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models.dart';
import '../services/claude_service.dart';

class QuizScreen extends StatefulWidget {
  final Subject subject;
  const QuizScreen({super.key, required this.subject});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  QuizQuestion? _question;
  bool _loading = true;
  bool _error = false;
  int? _selected;
  bool _revealed = false;
  int _correct = 0;
  int _total = 0;

  @override
  void initState() {
    super.initState();
    _loadQuestion();
  }

  Future<void> _loadQuestion() async {
    setState(() {
      _loading = true;
      _error = false;
      _question = null;
      _selected = null;
      _revealed = false;
    });
    try {
      final q = await ClaudeService.generateQuiz(widget.subject);
      setState(() {
        _question = q;
        _loading = false;
      });
    } catch (_) {
      setState(() {
        _loading = false;
        _error = true;
      });
    }
  }

  void _selectAnswer(int idx) {
    if (_revealed) return;
    final correct = idx == _question!.correct;
    setState(() {
      _selected = idx;
      _revealed = true;
      _total++;
      if (correct) _correct++;
    });
  }

  Color _optionColor(int idx) {
    if (!_revealed) {
      return _selected == idx
          ? const Color(0xFF7C3AED).withOpacity(0.3)
          : Colors.white.withOpacity(0.05);
    }
    if (idx == _question!.correct) return const Color(0xFF059669).withOpacity(0.25);
    if (idx == _selected) return const Color(0xFFDC2626).withOpacity(0.25);
    return Colors.white.withOpacity(0.03);
  }

  Color _optionBorder(int idx) {
    if (!_revealed) {
      return _selected == idx
          ? const Color(0xFFA78BFA)
          : Colors.white.withOpacity(0.1);
    }
    if (idx == _question!.correct) return const Color(0xFF34D399);
    if (idx == _selected) return const Color(0xFFEF4444);
    return Colors.white.withOpacity(0.07);
  }

  String _optionSuffix(int idx) {
    if (!_revealed) return '';
    if (idx == _question!.correct) return ' ✓';
    if (idx == _selected && idx != _question!.correct) return ' ✗';
    return '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0F0C29), Color(0xFF1A1A4E), Color(0xFF24243E)],
          ),
        ),
        child: SafeArea(
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: Column(
              children: [
                _buildAppBar(),
                Expanded(child: _buildBody()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Colors.white.withOpacity(0.08)),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: Text(
                '← رجوع',
                style: GoogleFonts.tajawal(color: Colors.white, fontSize: 13),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              '${widget.subject.icon}  ${widget.subject.label}',
              style: GoogleFonts.tajawal(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: Colors.white,
              ),
            ),
          ),
          if (_total > 0)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFA78BFA).withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: const Color(0xFFA78BFA).withOpacity(0.3),
                ),
              ),
              child: Text(
                '$_correct/$_total ✓',
                style: GoogleFonts.tajawal(
                  fontSize: 13,
                  color: const Color(0xFFC4B5FD),
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) return _buildLoading();
    if (_error) return _buildError();
    return _buildQuestion();
  }

  Widget _buildLoading() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('🤔', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 16),
          Text(
            'جاري تحضير السؤال...',
            style: GoogleFonts.tajawal(color: const Color(0xFF94A3B8), fontSize: 16),
          ),
          const SizedBox(height: 20),
          const CircularProgressIndicator(
            color: Color(0xFFA78BFA),
            strokeWidth: 2,
          ),
        ],
      ),
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('⚠️', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 12),
          Text(
            'حدث خطأ في توليد السؤال',
            style: GoogleFonts.tajawal(color: const Color(0xFFFC8181), fontSize: 15),
          ),
          const SizedBox(height: 20),
          GestureDetector(
            onTap: _loadQuestion,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFFA78BFA).withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFA78BFA)),
              ),
              child: Text(
                'حاول مرة أخرى',
                style: GoogleFonts.tajawal(
                  color: const Color(0xFFC4B5FD),
                  fontSize: 14,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuestion() {
    final q = _question!;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Question card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white.withOpacity(0.1)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'السؤال',
                  style: GoogleFonts.tajawal(
                    fontSize: 11,
                    color: const Color(0xFFA78BFA),
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  q.question,
                  textDirection: TextDirection.rtl,
                  style: GoogleFonts.tajawal(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFFF0EAFF),
                    height: 1.6,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Options
          ...List.generate(q.options.length, (i) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: GestureDetector(
                onTap: () => _selectAnswer(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 16,
                  ),
                  decoration: BoxDecoration(
                    color: _optionColor(i),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _optionBorder(i), width: 2),
                  ),
                  child: Text(
                    '${q.options[i]}${_optionSuffix(i)}',
                    textDirection: TextDirection.rtl,
                    style: GoogleFonts.tajawal(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFFE0D8FF),
                    ),
                  ),
                ),
              ),
            );
          }),

          // Explanation + Next
          if (_revealed) ...[
            const SizedBox(height: 10),
            AnimatedOpacity(
              opacity: _revealed ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 400),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: const Color(0xFF3B82F6).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: const Color(0xFF3B82F6).withOpacity(0.25),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '💡  الشرح',
                      style: GoogleFonts.tajawal(
                        fontSize: 13,
                        color: const Color(0xFF93C5FD),
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      q.explanation,
                      textDirection: TextDirection.rtl,
                      style: GoogleFonts.tajawal(
                        fontSize: 14,
                        color: const Color(0xFFBFDBFE),
                        height: 1.7,
                      ),
                    ),
                    const SizedBox(height: 16),
                    GestureDetector(
                      onTap: _loadQuestion,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF7C3AED), Color(0xFF3B82F6)],
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Center(
                          child: Text(
                            'السؤال التالي  ←',
                            style: GoogleFonts.tajawal(
                              fontSize: 15,
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
